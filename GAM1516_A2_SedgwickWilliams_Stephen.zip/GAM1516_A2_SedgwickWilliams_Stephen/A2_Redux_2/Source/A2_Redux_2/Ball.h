// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Ball.generated.h"

UCLASS()
class A2_REDUX_2_API ABall : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	ABall();

	//Make a sphere.
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Custom")
		class USphereComponent* CollisionSphere;

	//So last time I worked on this I kept making typos on this.
	//Let's... Let's not do that again.
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Actor Visual")
	class UPaperSpriteComponent* BallSprite;
	//Bam. One and done.
	//That's the power of sleeping for a solid day.

	//MOVEMENT COMPONENT
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Custom")
	class UProjectileMovementComponent* ProjectileMovementComponent;
	//I have nothing fancy for this.
	//If I tried to have something witty for a name I'd probably just get decision paralysis.

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;


public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	//Gotta make the override for when we kill this ball.
	virtual void Destroyed() override;

	class UPrimitiveComponent* GetPhysicsComponent();


};
