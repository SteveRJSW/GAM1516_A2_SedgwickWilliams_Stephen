// Copyright Epic Games, Inc. All Rights Reserved.
//This is the base game mode that UE5 made automatically.
//It doesn't actually get used anywhere anymore. That's A2Pong.

#include "A2_Redux_2GameModeBase.h"
#include "Board.h"
#include "Kismet/GameplayStatics.h"
#include "EngineUtils.h"

AA2_Redux_2GameModeBase::AA2_Redux_2GameModeBase()
{
	//I don't remember why...
	int x = 2;
	//But I had this in the other project too.
}

void AA2_Redux_2GameModeBase::BeginPlay()
{
	Super::BeginPlay();
	//Our super Begin Play thing that runs through everything else...
	ABoard* Board = nullptr;
	//Set our board pointer.

	for (TActorIterator<AActor> ActorItr(GetWorld()); ActorItr; ++ActorItr)
	{
		Board = Cast<ABoard>(*ActorItr);
		//Set our board to an actor iterator cast to be a Board.
			if (Board != nullptr)
			{
				//If the board isn't a null pointer then we create a player controller pointer so that we possess the board camera.
				APlayerController* Controller = UGameplayStatics::GetPlayerController(GetWorld(), 0);
				break;
			}
	}
}