// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PlayerController.h"
#include "A2PlayerController.generated.h"

/**
 * 
 */
UCLASS()
class A2_REDUX_2_API AA2PlayerController : public APlayerController
{
	GENERATED_BODY()

public:
	//Get our stuff set up to possess the player pawn...
	virtual void OnPossess(APawn* aPawn) override;
	//And then when we drop the player pawn.
	virtual void OnUnPossess() override;

protected:
	//Gotta get our input going.
	virtual void SetupInputComponent() override;

	virtual void AcknowledgePossession(APawn* PossessedPawn) override;

	void MoveUp(float value);

	class AUEPlayerState* MyPlayerState;
	class APlayerPaddle* MyPlayerPaddle;
};
