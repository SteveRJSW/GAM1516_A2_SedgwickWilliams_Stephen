// Fill out your copyright notice in the Description page of Project Settings.


#include "Board.h"
#include "Ball.h"
#include "Camera/CameraComponent.h"
#include "Components/ArrowComponent.h"
#include "UObject/ConstructorHelpers.h"
#include "Components/BoxComponent.h"
#include "Kismet/GameplayStatics.h"
#include "A2Pong.h"
#include "PongGameState.h"


ABoard::ABoard()
{
	//C-C-Constructor!

	//Make our camera
	BoardCamera = CreateDefaultSubobject<UCameraComponent>("Pawns Camera");
	//Attach our camera
	BoardCamera->SetupAttachment(RootComponent);
	//Make sure it's in orthographic projection
	BoardCamera->SetProjectionMode(ECameraProjectionMode::Orthographic);
	//Set the orthographic width.
	BoardCamera->SetOrthoWidth(1000.f);
	//Put it into position.
	BoardCamera->SetRelativeLocation(FVector(0.f, 500.f, 0.f));
	//I'm tired, I was ready to give up on this assignment for now...
	//But I guess that's not happening.

	BoardCamera->SetRelativeRotation(FRotator(0.f, -90.f, 0.f));
	//Make sure the camera is the right way up.
	BoardCamera->bUsePawnControlRotation = false; 
	//Make sure the camera isn't using our player controller's rotation.

	//Make an arrow...
	BallSpawn = CreateDefaultSubobject<UArrowComponent>("BallSpawn");
	//Let's set up a size...
	BallSpawn->ArrowSize = 1.f;
	//Let's attach it to the root component, aka our board...
	BallSpawn->SetupAttachment(RootComponent);
	//Set it up so that it's not INSIDE said component...
	BallSpawn->SetRelativeLocation(FVector(0.f, 50.f, 0.f));
	//And rotate it I suppose. I just did this last time and eh.
	BallSpawn->SetRelativeRotation(FRotator(45.f, 0.f, 0.f));

	//Let's start making boxes.
	TopBorder = CreateDefaultSubobject <UBoxComponent>("TopBorder");
	BotBorder = CreateDefaultSubobject <UBoxComponent>("BotBorder");
	LeftGoal = CreateDefaultSubobject <UBoxComponent>("LeftGoal");
	RightGoal = CreateDefaultSubobject < UBoxComponent>("RIghtGoal");
	//Give them dimensions...
	TopBorder->SetBoxExtent(FVector(1080.f, 200.f, 140.f));
	BotBorder->SetBoxExtent(FVector(1080.f, 200.f, 140.f));
	LeftGoal->SetBoxExtent(FVector(200.f, 200.f, 480.f));
	RightGoal->SetBoxExtent(FVector(200.f, 200.f, 480.f));
	//Make sure they don't have gravity...
	TopBorder->SetSimulatePhysics(false);
	BotBorder->SetSimulatePhysics(false);
	LeftGoal->SetSimulatePhysics(false);
	RightGoal->SetSimulatePhysics(false);
	//Set our collisions...
	TopBorder->SetCollisionProfileName("BlockAllDynamic");
	BotBorder->SetCollisionProfileName("BlockAllDynamic");
	LeftGoal->SetCollisionProfileName("OverlapAllDynamic");
	RightGoal->SetCollisionProfileName("OverlapAllDynamic");
	//And give them all collision.
	TopBorder->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
	BotBorder->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
	LeftGoal->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
	RightGoal->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
	//And let's connect them all to the root object....
	TopBorder->SetupAttachment(RootComponent);
	BotBorder->SetupAttachment(RootComponent);
	LeftGoal->SetupAttachment(RootComponent);
	RightGoal->SetupAttachment(RootComponent);
	//Ok so totally forgot about this, but have to ADD DYNAMIC to the goals.
	LeftGoal->OnComponentBeginOverlap.AddDynamic(this, &ABoard::LeftOverlap);
	RightGoal->OnComponentBeginOverlap.AddDynamic(this, &ABoard::RightOverlap);
}

void ABoard::LeftOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	if (OtherActor && OtherActor != this)
	{
		//Aka, if there's something overlapping this box, and said overlapping thing isn't also this box.
		if (OtherActor->IsA<ABall>())
		{
			//And if that thing happens to be a ball...
			OtherActor->Destroy();
			//DESTROY IT.

			//Let's make our temporary game mode...
			AA2Pong* gameMode = Cast<AA2Pong>(GetWorld()->GetAuthGameMode());
			//And then our temporary game state...
			APongGameState* gameState = gameMode->GetGameState<APongGameState>();
			//Then let's iterate the goals on player.
			gameState->NumGoalsOnPlayer++;

			//ANd then we take our bool and set it to false so the game knows that there's no ball in play.
			bBallSpawned = false;

			//And then we use this to spawn the ball on a slight delay, using the values that we set in the header...
			GetWorldTimerManager().SetTimer(StartTime, this, &ABoard::SpawnBall, delayValue, false);

			//And then let's set this bool to true again.
			bBallSpawned = true;
			//THere's literally no reason for this anymore, but I think it's funny.


		}
	}

}

void ABoard::RightOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	//Same as above, copy and pasted, complete with notes.
	if (OtherActor && OtherActor != this)
	{
		//Aka, if there's something overlapping this box, and said overlapping thing isn't also this box.
		if (OtherActor->IsA<ABall>())
		{
			//And if that thing happens to be a ball...
			OtherActor->Destroy();
			//DESTROY IT.

			//Do the same as above down here...
			AA2Pong* gameMode = Cast<AA2Pong>(GetWorld()->GetAuthGameMode());
			//Making our temporary variables...
			APongGameState* gameState = gameMode->GetGameState<APongGameState>();
			//But on the AI this time.
			gameState->NumGoalsOnAI++;

			//See above. Just telling the program that there's no ball active.
			bBallSpawned = false;

			//Do the timer thing
			GetWorldTimerManager().SetTimer(StartTime, this, &ABoard::SpawnBall, delayValue, false);

			//And then the silly thing that serves no purpose.
			bBallSpawned = true;


		}
	}

}

void ABoard::BeginPlay()
{
	//Time to make it so that we can actually play the game with our fancy player controller.
	APlayerController* PONG = UGameplayStatics::GetPlayerController(GetWorld(), 0);

	if (PONG != nullptr)
	{
		//If our player controller isn't a null pointer...
		PONG->SetViewTargetWithBlend(this, 0.f);
		//THen it should possess this camera.
	}

	if (bBallSpawned == false)
	{
		SpawnBall();
	}

}

void ABoard::SpawnBall()
{
	//So if our Ball is not null pointer...
	if (PongBall != nullptr)
	{
		UWorld* World = GetWorld();
		//And our world is also not a null pointer...
		if (World)
		{
			FActorSpawnParameters SpawnParams;
			SpawnParams.Owner = this;
			SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

			FTransform SpawnTransform = BallSpawn->GetComponentTransform();
			ABall* SpawnedActor = World->SpawnActor<ABall>(PongBall, SpawnTransform, SpawnParams);
			if (SpawnedActor)
			{
				FVector direction = FRotationMatrix(SpawnTransform.Rotator()).GetScaledAxis(EAxis::X);
				//GEngine->AddOnScreenDebugMessage(-1, 15.0f, FColor::Blue, "Spawn Projectile");
				//This line of code here was for debugging purposes.
			}

		}
	}
	bBallSpawned = true;
}
