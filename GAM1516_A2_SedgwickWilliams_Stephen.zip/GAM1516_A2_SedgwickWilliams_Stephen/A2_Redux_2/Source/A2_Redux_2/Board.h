// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "PaperSpriteActor.h"
#include "Board.generated.h"

/**
 * 
 */
UCLASS()
class A2_REDUX_2_API ABoard : public APaperSpriteActor
{
	GENERATED_BODY()
	
public:
	ABoard(); //Need that ol' constructor.
	//Like I said in the other file that I'm replacing... Make sure you specify this is public.
	//Otherwise, it becomes a private constructor and CAUSES ISSUES.

	//We need a camera attached to our board.
	UPROPERTY(VisibleAnywhere, Category = "BoardCamera")
	class UCameraComponent* BoardCamera; //Beep boop.
	//Gotta make sure everything is forward declared.

	//Forward declare our arrow for the spawning of balls.
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Custom")
	class UArrowComponent* BallSpawn;
	//Heheheh
	//All my OG Baldur's Gate players will get this one.

	//Make a ball.
	UPROPERTY(EditDefaultsOnly, Category = Ball)
	TSubclassOf<class ABall> PongBall;

	//Let's make all of our boxes...
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Custom")
	class UBoxComponent* TopBorder;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Custom")
	class UBoxComponent* BotBorder;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Custom")
	class UBoxComponent* LeftGoal;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Custom")
	class UBoxComponent* RightGoal;

	//Just a little thing to do for keeping track of if the ball is alive or not.
	bool bBallSpawned = false;

	UFUNCTION()
	void LeftOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
	//This is really long, and I asked someone if I really needed all of it.
	//And they said it gets angry if you don't type it all.
	//So here we are.

	UFUNCTION()
	void RightOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
	//But that does mean that I'm going to be copy pasting it for the Right one and the definitions.
	//Or, rather... I'm going to auto-generate the definitions so I don't have to type it all again.

protected:
	void BeginPlay();


	//Float for delay on respawning ball.
	float delayValue = 2.f;
	//FTimerHandle for the making of the timer for respawning the ball.
	FTimerHandle StartTime;

private:
	void SpawnBall();
	
};
