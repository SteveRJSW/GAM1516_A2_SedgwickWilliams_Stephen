// Fill out your copyright notice in the Description page of Project Settings.


#include "Ball.h"
#include "Components/SphereComponent.h"
#include "PaperSpriteComponent.h"
#include "GameFramework/ProjectileMovementComponent.h"


// Sets default values
ABall::ABall()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	//As always, let's start with the sphere.

	//Make the collision object first...
	CollisionSphere = CreateDefaultSubobject<USphereComponent>("RootComponent");
	//Set the size...
	CollisionSphere->SetSphereRadius(25.f);
	//Make sure it doesn't have gravity...
	CollisionSphere->SetSimulatePhysics(false);
	//Get it to bounce off stuff...
	CollisionSphere->SetCollisionProfileName("BlockAll");
	//And I mean everything...
	CollisionSphere->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
	//Make sure it can't rotate...
	CollisionSphere->GetBodyInstance()->bLockRotation = true;
	//Let's stop it from shooting out of the frame...
	CollisionSphere->GetBodyInstance()->bLockYTranslation = true;
	//And finally... set it as the root object.
	SetRootComponent(CollisionSphere);
	//So it turns out one of the biggest issues I was having previously is that I just wasn't settting things as root components.
	//The power of sleep... you remember things and realize things were broken.

	//Next up... The sprite!
	BallSprite = CreateDefaultSubobject<UPaperSpriteComponent>("BallSprite");
	//Make sure the sprite doesn't collide with anything.
	BallSprite->SetCollisionProfileName("NoCollision");
	//And I mean REALLY make sure of that.
	BallSprite->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	//Make sure it can overlap with stuff because that's kind of the entire point, you know?
	BallSprite->SetGenerateOverlapEvents(true);
	//Just gonna be really hard to play Pong if it can't overlap.
	//Kind of like trying to play soccer/football with no ball.
	BallSprite->SetupAttachment(RootComponent);

	//THE MOVEMENT
	//First, let's actually set it.
	ProjectileMovementComponent = CreateDefaultSubobject<UProjectileMovementComponent>("BallMovement");
	//Let's make it able to bounce.
	ProjectileMovementComponent->bShouldBounce = true;
	//Next let's set its bounciness.
	ProjectileMovementComponent->Bounciness = 1.0f;
	//Now let's make sure it has no gravity.
	ProjectileMovementComponent->ProjectileGravityScale = 0.f;
	//Get outta here gravity.
	//Always keeping me down!
	//Ok, let's make sure that it updates and such.
	ProjectileMovementComponent->bSimulationEnabled = true;
	//Really wishing I had chosen a shorter name at this point.
	//Let's make sure it has no friction.
	ProjectileMovementComponent->Friction = 0.f;
	//Give it an initial speed...
	ProjectileMovementComponent->InitialSpeed = 500.f;
	//And a max speed...
	//Of which it will not have one.
	ProjectileMovementComponent->MaxSpeed = 0;



}

// Called when the game starts or when spawned
void ABall::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void ABall::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	//First we need to get the normal...
	ProjectileMovementComponent->Velocity += GetVelocity().GetSafeNormal();
	//Then we need to add it to our velocity.
	//I intended to write this as two lines of code but it worked in one so... I dunno. Cool!

}

void ABall::Destroyed()
{
}

UPrimitiveComponent* ABall::GetPhysicsComponent()
{
	return nullptr;
}

