// Fill out your copyright notice in the Description page of Project Settings.


#include "PlayerPaddle.h"
#include "PaperSpriteComponent.h"
#include "Components/BoxComponent.h"

// Sets default values
APlayerPaddle::APlayerPaddle()
{
	// Set this pawn to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	//So I found out that #Pragma Region is a block of code that you can collapse.
	//Kinda sad that I didn't know that before.
#pragma region Hierarhcy 2
	//There we got something going.
	PaddleRootCollisionBox = CreateDefaultSubobject<UBoxComponent>("RootComponent");
	//Now we got a box.
	PaddleRootCollisionBox->SetBoxExtent(FVector(10, 25, 100));
	//Our box has dimensions.
	PaddleRootCollisionBox->SetSimulatePhysics(false);
	//I assume this has to be false so that the paddle doesn't just fall into the void because gravity.
	PaddleRootCollisionBox->SetEnableGravity(false);
	//Or is this how to change gravity?
	PaddleRootCollisionBox->SetCollisionProfileName("BlockAllDynamic");
	PaddleRootCollisionBox->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
	//Get the paddle to collide with everything.
	//And now time to make sure it can't rotate or move side to side.
	PaddleRootCollisionBox->GetBodyInstance()->bLockRotation = true;
	//And just to make sure it can't move in any way I don't want it to...
	PaddleRootCollisionBox->GetBodyInstance()->bLockXTranslation = true;
	PaddleRootCollisionBox->GetBodyInstance()->bLockYTranslation = true;
	//Gotta set this as my root component. Naming it that way isn't enough, gotta do this too.
	SetRootComponent(PaddleRootCollisionBox);

	//Sprite time!
	PawnSpriteComponent = CreateDefaultSubobject<UPaperSpriteComponent>("Pawn Sprite");
	//Gotta make it so the sprite works...
	PawnSpriteComponent->SetupAttachment(RootComponent);
	//Gotta make it so the sprite actually attaches to the box...
	PawnSpriteComponent->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	//Aaaand let's make sure that the sprite doesn't actually collide with the box.
	//Not pictured: me making repeated typos on "Component" resulting in crashes.

	//Make sure it doesn't rotate with the controller rotates...
	bUseControllerRotationPitch = false;
	bUseControllerRotationYaw = false;
	bUseControllerRotationRoll = false;
	//Every time I type these in I want to play Ace Combat/Make an Ace Combat-esque game.

	//Speed stuff.
	MovementSpeed = 5;
	//Not actually sure if I need the regular speed when I have a non-variable speed on the paddle? 
	Speed = MovementSpeed;
}

// Called when the game starts or when spawned
void APlayerPaddle::BeginPlay()
{
	Super::BeginPlay();

	
}

// Called every frame
void APlayerPaddle::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	//Making movement, making bacon movement...
	FVector NewLocation = GetActorLocation();
	//Losing my mind and putting in a Jake song.
	if (MovementUp != 0)
	{
		//If we're moving, then we're moving.
		NewLocation = GetActorLocation() + (GetActorUpVector() * MovementUp * Speed);
	}

	SetActorLocation(NewLocation, true);
	//Thank you for bringing this up in class, Konstantin!

}

// Called to bind functionality to input
void APlayerPaddle::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

}

void APlayerPaddle::MoveUp(float value)
{
	//Time to get this player paddle to move!
	MovementUp = value;
	//And... that's it!
	//Easy peasey.
}
