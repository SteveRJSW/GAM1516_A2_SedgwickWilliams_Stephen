// Fill out your copyright notice in the Description page of Project Settings.


#include "PongGameState.h"

APongGameState::APongGameState()
{
	NumGoalsOnAI = 0;
	NumGoalsOnPlayer = 0;
	//Not sure if I actually need to do this, but I figure it's how I've generally setup floats.
	//So eh.
}

int APongGameState::GetNumGoalsOnPlayer()
{
	//Have this return the number of Goals on the Player...
	return NumGoalsOnPlayer;
}

int APongGameState::GetNumGoalsOnAI()
{
	//And have this one return the number of Goals on the AI....
	return NumGoalsOnAI;
}
