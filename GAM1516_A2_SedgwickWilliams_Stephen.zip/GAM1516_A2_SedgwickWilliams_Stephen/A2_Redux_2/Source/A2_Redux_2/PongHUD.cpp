// Fill out your copyright notice in the Description page of Project Settings.


#include "PongHUD.h"
#include "Blueprint/UserWidget.h"
#include "UObject/ConstructorHelpers.h"

APongHUD::APongHUD()
{
	static ConstructorHelpers::FClassFinder<UUserWidget> playerHud(TEXT("/Game/Blueprints/UI/PlayerUI"));
	if (playerHud.Succeeded())
		PlayerGuiClass = playerHud.Class;
}
void APongHUD::BeginPlay()
{
	//ALright, let's get this GUI going.
	//first we have to create the Gui widget...
	//We do this by assigning the return value of CreateWidget<UUserWidget>() and passing in what you see down there.
	PlayerGui = CreateWidget<UUserWidget>(GetGameInstance(), PlayerGuiClass);
	//And then we have to add it to the viewport.
	PlayerGui->AddToViewport();
	//And, if I understand it, that should work!
	//Yeah, I should have known better than to type that. It broke.
	//Well I kind of fixed it now?
}