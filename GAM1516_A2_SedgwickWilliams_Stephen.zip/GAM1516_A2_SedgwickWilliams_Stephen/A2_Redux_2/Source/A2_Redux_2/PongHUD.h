// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/HUD.h"
#include "PongHUD.generated.h"

/**
 * 
 */
UCLASS()
class A2_REDUX_2_API APongHUD : public AHUD
{
	GENERATED_BODY()

public:
	APongHUD();

	//Let's get our GUI going...
	UPROPERTY(EditAnywhere, Category = "Game Hud")
		TSubclassOf<class UUserWidget> PlayerGuiClass;

	UPROPERTY()
		class UUserWidget* PlayerGui;

protected:
	virtual void BeginPlay() override;

	
};
