// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "A2_Redux_2GameModeBase.generated.h"

/**
 * 
 */
UCLASS()
class A2_REDUX_2_API AA2_Redux_2GameModeBase : public AGameModeBase
{
	GENERATED_BODY()

public:
	AA2_Redux_2GameModeBase();

protected:
	//called when the game starts or when spawned.
	virtual void BeginPlay() override;
	
};
