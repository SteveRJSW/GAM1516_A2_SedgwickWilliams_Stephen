// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "A2Pong.generated.h"

/**
 * 
 */
UCLASS()
class A2_REDUX_2_API AA2Pong : public AGameModeBase
{
	GENERATED_BODY()

public:
	AA2Pong();

	void BeginPlay();
	
};
