// Copyright Epic Games, Inc. All Rights Reserved.

#include "A2_Redux_2.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, A2_Redux_2, "A2_Redux_2" );
