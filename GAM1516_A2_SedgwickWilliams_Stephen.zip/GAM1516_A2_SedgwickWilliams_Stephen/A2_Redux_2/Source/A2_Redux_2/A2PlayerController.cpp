// Fill out your copyright notice in the Description page of Project Settings.


#include "A2PlayerController.h"
#include "PlayerPaddle.h"

void AA2PlayerController::OnPossess(APawn* aPawn)
{
	Super::OnPossess(aPawn);

	MyPlayerPaddle = Cast<APlayerPaddle>(aPawn);

}

void AA2PlayerController::OnUnPossess()
{
	APawn* possessedPawn = Cast<APawn>(GetOwner());
	if (possessedPawn != nullptr)
	{
		Super::OnUnPossess();
	}
}

void AA2PlayerController::SetupInputComponent()
{
	Super::SetupInputComponent();
	if (InputComponent != nullptr)
	{
		InputComponent->BindAxis("Up", this, &AA2PlayerController::MoveUp);
	}
}

void AA2PlayerController::AcknowledgePossession(APawn* PossessedPawn)
{
}

void AA2PlayerController::MoveUp(float value)
{
	if (MyPlayerPaddle != nullptr)
	{
		MyPlayerPaddle->MoveUp(value);
	}
}

