// Fill out your copyright notice in the Description page of Project Settings.


#include "AIPaddle.h"
#include "Ball.h"
#include "PaperSpriteComponent.h"
#include "Components/BoxComponent.h"
#include "Kismet/GameplayStatics.h"
#include "EngineUtils.h"

// Sets default values
AAIPaddle::AAIPaddle()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	//Let's get the usual done...
	AIRootCollisionBox = CreateDefaultSubobject<UBoxComponent>("SceneRoot");
	//Size
	AIRootCollisionBox->SetBoxExtent(FVector(10, 25, 100));
	//Turn off gravity.
	AIRootCollisionBox->SetSimulatePhysics(false);
	//Give it some collision
	AIRootCollisionBox->SetCollisionProfileName("BlockAllDynamic");
	AIRootCollisionBox->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
	//Let's keep it going.
	//No rotation
	AIRootCollisionBox->GetBodyInstance()->bLockRotation = true;
	//Make sure it can't leave its Y and X axis...
	AIRootCollisionBox->GetBodyInstance()->bLockXTranslation = true;
	AIRootCollisionBox->GetBodyInstance()->bLockYTranslation = true;
	//Set it to be the root component.
	SetRootComponent(AIRootCollisionBox);

	//Now let's give it a sprite...
	AISpriteComponent = CreateDefaultSubobject<UPaperSpriteComponent>("AI Sprite");
	//Make sure that it's connected to the paddle...
	AISpriteComponent->SetupAttachment(RootComponent);
	//And also make sure that it doesn't have collision because that would be weird.
	AISpriteComponent->SetCollisionEnabled(ECollisionEnabled::NoCollision);

	//Speed.
	MovementSpeed = 2.5f;
	Speed = MovementSpeed;


}

// Called when the game starts or when spawned
void AAIPaddle::BeginPlay()
{
	Super::BeginPlay();
	FindBall();
}

// Called every frame
void AAIPaddle::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	FindBall();

	//Let's just track the ball for now...
	FVector targetLoc = TargetBall->GetActorLocation();
	targetZ = targetLoc.Z;
	//THIS IS CASE SENSITIVE
	FVector currentLoc = GetActorLocation();
	FVector newLoc = FVector(currentLoc.X, targetLoc.Y, targetLoc.Z);

	MovePaddle();

	//So the issue was that my AI paddle was spawning inside the bounding box of something else and wasn't moving.
	//Moving it made everything work as intended.
		//I'm really not sure why, but it seems that it needs both the target Y and Z location to move the AI paddle.
		//If either one isn't used then it breaks.
		//SetActorLocation(newLoc, true);

	

	//Behold, a well of lost dreams.
	/*	 //WHAT DO YOU MEAN THE Z VALUE IN UNREAL READS FROM THE Y VALUE IN AN FVECTOR?
		//So much time spent and the solution was "make the Z upper case" aaaaaaaaaaa

		//GetWorldTimerManager().SetTimer(startTimer, this, &AAIPaddle::MovePaddle, delayValue, false);
	
		//MovePaddle();

		//Ok, so this code here?
		//SetActorLocation(newlocation, true);
		//This just teleports the paddle to wherever the ball is.
		// Not exactly the solution I'm looking for.
		//We'll worry about interpolation later.
		//WE WORRIED ABOUT IT NOW.
	*/
	//Sure this was all already commented out, but I EXTRA commented it out.
}

void AAIPaddle::FindBall()
{
	//Reusing this code we used to find a camera before to find the ball now...
	for (TActorIterator<AActor> ActorItr(GetWorld()); ActorItr; ++ActorItr)
	{
		//I have been advised to ALWAYS have a null check...
		//Just in case...
		if (*ActorItr != nullptr)
		{
			//Just learned about this IsA function. That's really cool.
			if (ActorItr->IsA<ABall>())
			{
				//ANyways, assuming that we find a ball, then the target ball becomes The Ball we found.
				TargetBall = Cast<ABall>(*ActorItr);
				return;
			}
		}
	}
}

void AAIPaddle::MovePaddle()
{
	//My attempt at interpolating.
	//Didn't work out.

	FVector newLocation;
	FVector myLoc = GetActorLocation();
	float myZ = myLoc.Z;

	if (myZ > targetZ)
	{
		newLocation = GetActorLocation() + (GetActorUpVector() * - 1 * Speed);
	}
	else if (myZ < targetZ)
	{
		newLocation = GetActorLocation() + (GetActorUpVector() * 1 * Speed);
	}
	else
	{
		newLocation = GetActorLocation();
	}

	SetActorLocation(newLocation, true);

	//SetActorLocation(FVector(myLoc.X, newLocation.Y, newLocation.Z), true);

	

}

