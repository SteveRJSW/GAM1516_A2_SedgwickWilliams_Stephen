// Fill out your copyright notice in the Description page of Project Settings.


#include "A2Pong.h"

AA2Pong::AA2Pong()
{
	//I have no reason to do this...
	int x = 2;
	//But at this point it's tradition.
}

void AA2Pong::BeginPlay()
{
	Super::BeginPlay();
	//Make sure all those lovely begin play functions/methods run.
}